#!/usr/bin/env python3
"""One-run recovery: preserve completed repeats, finish scale, publish, clean."""
import csv
import datetime
import fcntl
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import traceback

REPO = Path('/mnt/c/Users/wangx/Projects/CerebroNexus')
CACHE = Path('/home/wang/.cache/cerebronexus-benchmark')
SCRATCH = CACHE / 'scratch/cerebro-bench.NLsggX'
STAGE = SCRATCH / 'result'
STATE = CACHE / 'runner'
CODE = SCRATCH / 'recovery-code'
SCRIPT_DIR = 'tests/benchmarks/expression-backends/scripts'
SHA = 'b64f8df3ce5bc553b7084dfdaca3698aa69f475c'
RUN = '20261014T224107Z-b64f8df3ce5b-scale'
INCOMPLETE = ('human_pfc_hbcc', 50000, 'embedded', 2)

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def note(message):
    print('[' + now() + '] ' + message, flush=True)

def atomic(path, data):
    tmp = path.with_name(path.name + '.recovery-tmp')
    with tmp.open('wb') as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def clean_bytes(path):
    raw = path.read_bytes()
    start = raw.find(b'\0')
    if start >= 0:
        assert not raw[start:].strip(b'\0'), 'non-trailing corruption: ' + str(path)
        raw = raw[:start]
    assert raw.endswith(b'\n'), 'incomplete CSV record: ' + str(path)
    return raw

def rows(path):
    return list(csv.DictReader(io.StringIO(clean_bytes(path).decode())))

def key(row):
    return (row['source'], int(float(row['n_cells'])), row['backend'], int(row['export_repeat']))

def schedule_rows():
    data = rows(STAGE / '05_schedule.csv')
    # The original shell runner visits each source, filtering the schedule.
    return [r for source in dict.fromkeys(r['source'] for r in data) for r in data if r['source'] == source]

def safe_remove(path):
    root = (CACHE / 'scratch').resolve()
    target = path.resolve()
    assert target.is_relative_to(root) and target != root
    assert (SCRATCH / '.cerebro-benchmark-scratch').is_file()
    shutil.rmtree(target)

def sync_results():
    for path in STAGE.glob('*.csv'):
        with path.open('rb') as handle:
            os.fsync(handle.fileno())

def check_access(data):
    for row in data:
        assert row['status'] == 'OK' and row['correctness'] == 'OK'
        assert row['access_contract'] == 'materialized-v2'
        for field in ('row', 'block', 'subset_row', 'subset_block'):
            assert row[field + '_fingerprint'] == row['reference_' + field + '_fingerprint']

def preflight():
    assert SCRATCH.resolve().parent == (CACHE / 'scratch').resolve()
    assert (SCRATCH / '.cerebro-benchmark-scratch').is_file()
    assert subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip() == SHA
    manifest = {r['key']: r['value'] for r in rows(STAGE / 'run_manifest.csv')}
    assert manifest['run_id'] == RUN and manifest['git_sha'] == SHA and manifest['profile'] == 'scale'
    schedule = schedule_rows()
    exports = rows(STAGE / '10_export.csv')
    access = rows(STAGE / '20_access.csv')
    assert (len(schedule), len(exports), len(access)) == (170, 121, 241)
    assert not rows(STAGE / 'crashes.csv')
    assert len(set(map(key, schedule))) == 170
    assert list(map(key, exports)) == list(map(key, schedule[:121]))
    assert key(exports[-1]) == INCOMPLETE and all(r['status'] == 'OK' for r in exports)
    assert not list((SCRATCH / 'export').iterdir()), 'unexpected retained artifacts'
    check_access(access)
    for index, build in enumerate(exports):
        records = [r for r in access if key(r) == key(build)]
        assert [int(r['access_repeat']) for r in records] == ([1] if index == 120 else [1, 2])
        assert all(r['query_plan_fingerprint'] == build['query_plan_fingerprint'] for r in records)
    plans = {(r['source'], int(float(r['n_cells']))): r for r in rows(STAGE / 'query_plan_manifest.csv')}
    assert len(plans) == 12
    for build in exports:
        assert build['query_plan_fingerprint'] == plans[key(build)[:2]]['query_plan_fingerprint']
    return manifest, schedule, exports, access

def prepare():
    manifest, schedule, exports, access = preflight()
    assert not (STAGE / 'recovery.json').exists(), 'recovery already prepared'
    for relative in [SCRIPT_DIR + '/benchmark.R', SCRIPT_DIR + '/benchmark_cli.R', 'default.nix']:
        original = subprocess.check_output(['git', '-C', str(REPO), 'show', SHA + ':' + relative])
        assert (REPO / relative).read_bytes().replace(b'\r\n', b'\n') == original
        target = CODE / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(original)
    archive = STAGE / 'logs/recovery-inputs.tar.gz'
    with tarfile.open(archive, 'w:gz') as tar:
        for path in STAGE.glob('*.csv'):
            tar.add(path, arcname='original/' + path.name)
        tar.add(STATE / 'benchmark.log', arcname='original/benchmark.log')
        for path in (STAGE / 'logs').glob('*human_pfc_hbcc_50000_embedded_r2*'):
            tar.add(path, arcname='original/logs/' + path.name)
        tar.add(Path(__file__), arcname='continue-scale.py')
        tar.add(CODE, arcname='code')
    recovery = {
        'started_at_utc': now(), 'source_commit': SHA, 'run_id': RUN,
        'preserved_builds': 120, 'preserved_accesses': 240,
        'remaining_schedule_entries': 50,
        'reason': 'Interrupted process; trailing NUL bytes in access/crash files. Artifact for incomplete repeat no longer exists. Rebuild that complete repeat, preserving all 120 completed repeats unchanged.',
        'superseded_build': exports[-1], 'superseded_access': access[-1],
        'original_files': {p.name: {'sha256': digest(p), 'trailing_nul_bytes': len(p.read_bytes()) - len(clean_bytes(p))} for p in STAGE.glob('*.csv')},
        'archive_sha256': digest(archive),
        'full_current_before': (REPO / 'tests/benchmarks/results/expression-backends/full/CURRENT').read_text(),
        'full_evidence_sha256_before': digest(REPO / 'tests/benchmarks/results/expression-backends/full/runs/20261014T194814Z-b64f8df3ce5b-full/evidence_manifest.csv'),
    }
    atomic(STAGE / 'recovery.json', (json.dumps(recovery, indent=2) + '\n').encode())
    # Retain complete CSV records byte-for-byte, including their original timings.
    for filename in ['10_export.csv', '20_access.csv']:
        data = clean_bytes(STAGE / filename)
        lines = data.splitlines(keepends=True)
        assert len(lines) == len(rows(STAGE / filename)) + 1
        atomic(STAGE / filename, b''.join(lines[:-1]))
    atomic(STAGE / 'crashes.csv', clean_bytes(STAGE / 'crashes.csv'))
    note('Preserved 120 builds and 240 accesses; 50 schedule entries remain.')

def inside():
    os.chdir(REPO)
    env = os.environ.copy()
    env.update({
        'BENCH_ROOT': str(CODE / SCRIPT_DIR), 'BENCH_SCRATCH': str(SCRATCH),
        'BENCH_LIB': str(SCRATCH / 'rlib'), 'R_LIBS_USER': str(SCRATCH / 'r-user-library'),
        'R_ENVIRON_USER': '/dev/null', 'R_PROFILE_USER': '/dev/null', 'NOT_CRAN': 'true',
        'BENCH_RUN_ID': RUN, 'BENCH_STUDY_ID': RUN, 'BENCH_PROFILE': 'scale', 'BENCH_THREADS': '1',
    })
    for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS','RCPP_PARALLEL_NUM_THREADS']:
        env[name] = '1'
    rscript = shutil.which('Rscript')
    assert rscript and rscript.startswith('/nix/store/'), rscript
    verify = r'''
    .libPaths(c(Sys.getenv('BENCH_LIB'), .libPaths()))
    source(file.path(Sys.getenv('BENCH_ROOT'), 'benchmark.R'))
    s <- file.path(Sys.getenv('BENCH_SCRATCH'), 'result')
    m <- read.csv(file.path(s, 'run_manifest.csv'))
    values <- setNames(m$value, m$key)
    stopifnot(identical(R.version.string, values[['r_version']]))
    for (name in setdiff(names(values)[startsWith(names(values), 'package_')], 'package_version')) {
      package <- sub('^package_', '', name)
      stopifnot(identical(as.character(packageVersion(package)), values[[name]]))
    }
    schedule <- read.csv(file.path(s,'05_schedule.csv'))
    exports <- read.csv(file.path(s,'10_export.csv'))
    access <- read.csv(file.path(s,'20_access.csv'))
    completed <- schedule[match(.bench_result_key(exports), .bench_result_key(schedule)),]
    bench_validate_results(completed, exports, access, profile=bench_profile('scale'))
    plans <- read.csv(file.path(s,'query_plan_manifest.csv'))
    for (i in seq_len(nrow(plans))) {
      p <- plans[i,]
      plan <- readRDS(file.path(Sys.getenv('BENCH_SCRATCH'), 'query-plans', paste0(p$source, '_', sprintf('%.0f',p$n_cells), '.rds')))
      stopifnot(identical(plan$query_plan_fingerprint,p$query_plan_fingerprint))
      fingerprint <- plan$query_plan_fingerprint
      plan$query_plan_fingerprint <- NULL
      stopifnot(identical(bench_serialized_fingerprint(plan),fingerprint))
    }
    cat('Original package versions, 120 complete repeats, and all frozen plans verified.\n')
    '''
    subprocess.run([rscript, '--vanilla', '-'], input=verify, text=True, env=env, check=True)
    sources = rows(STAGE / 'source_manifest.csv')
    source = next(r for r in sources if r['source'] == 'human_pfc_hbcc')
    source_path = SCRATCH / 'sources' / source['url'].split('?')[0].rsplit('/',1)[1]
    assert source_path.stat().st_size == int(source['bytes'])
    note('Verifying cached human source checksum; no download.')
    assert digest(source_path) == source['sha256']
    assert shutil.disk_usage(SCRATCH).free > 70 * 1024**3
    cli = CODE / SCRIPT_DIR / 'benchmark_cli.R'

    def run_cli(arguments, logfile=None):
        command = [rscript, str(cli)] + list(map(str, arguments))
        if logfile:
            with logfile.open('w') as handle:
                subprocess.run(command, env=env, stdout=handle, stderr=subprocess.STDOUT, check=True)
            note('\n'.join(logfile.read_text(errors='replace').splitlines()[-3:]))
        else:
            subprocess.run(command, env=env, check=True)
        sync_results()

    schedule = schedule_rows()
    assert len(rows(STAGE / '10_export.csv')) == 120
    for i, planned in enumerate(schedule[120:], start=121):
        src, tier, backend, repeat = key(planned)
        assert src == 'human_pfc_hbcc'
        position = int(planned['order_position'])
        tag = f'{src}_{tier}_{backend}_r{repeat}'
        plan = SCRATCH / 'query-plans' / f'{src}_{tier}.rds'
        out = SCRATCH / 'export' / tag
        assert not out.exists()
        note(f'[{i}/170] {tag}: build')
        run_cli(['export' if backend == 'embedded' else 'build-full', src, tier, backend, repeat, position, SCRATCH, STAGE/'10_export.csv', plan], STAGE/'logs'/f'export_{tag}.log')
        builds = rows(STAGE/'10_export.csv')
        assert len(builds) == i and key(builds[-1]) == key(planned)
        status = builds[-1]['status']
        if status != 'OK':
            assert backend == 'embedded' and status.startswith('SKIPPED(resource):'), status
            note(status)
        else:
            assert (out/'bench.crb').is_file()
            for access_repeat in range(1, int(planned['access_repeats']) + 1):
                note(f'[{i}/170] {tag}: access {access_repeat}/2')
                before = len(rows(STAGE/'20_access.csv'))
                run_cli(['access', src, tier, backend, repeat, position, access_repeat, out/'bench.crb', STAGE/'20_access.csv', plan], STAGE/'logs'/f'access_{tag}_a{access_repeat}.log')
                measurements = rows(STAGE/'20_access.csv')
                assert len(measurements) == before + 1 and key(measurements[-1]) == key(planned)
                assert int(measurements[-1]['access_repeat']) == access_repeat
                check_access(measurements[-1:])
        if out.exists():
            safe_remove(out)
    note('All 170 schedule entries recorded; validating and generating report.')
    run_cli(['validate', STAGE])
    run_cli(['report', STAGE], STAGE/'logs/report-recovery.log')
    run_cli(['figure', STAGE, STAGE/'figures'], STAGE/'logs/figures-recovery.log')
    recovery = json.loads((STAGE/'recovery.json').read_text())
    recovery['measurements_completed_at_utc'] = now()
    recovery['final_build_records'] = len(rows(STAGE/'10_export.csv'))
    recovery['final_access_records'] = len(rows(STAGE/'20_access.csv'))
    assert recovery['full_current_before'] == (REPO/'tests/benchmarks/results/expression-backends/full/CURRENT').read_text()
    assert recovery['full_evidence_sha256_before'] == digest(REPO/'tests/benchmarks/results/expression-backends/full/runs/20261014T194814Z-b64f8df3ce5b-full/evidence_manifest.csv')
    recovery['full_run_unchanged'] = True
    atomic(STAGE/'recovery.json', (json.dumps(recovery, indent=2)+'\n').encode())
    summary = STAGE/'summary.md'
    with summary.open('a') as handle:
        handle.write('\n## Interrupted-run recovery\n\nThis scale study resumed on 2026-10-15 using the original commit, installed package versions, source checksum and frozen query plans. The first 120 builds and 240 reads were retained unchanged. The incomplete human 50k embedded repeat 2 was repeated in full because its artifact was unavailable; the remaining scheduled entries then ran in their original order. Original interrupted records and the recovery script are preserved in `logs/recovery-inputs.tar.gz`; details are in `recovery.json`. The full-dataset study was not rerun.\n')
    run_cli(['evidence', STAGE])
    run_cli(['check', STAGE])
    destination_root = REPO/'tests/benchmarks/results/expression-backends/scale'
    run_cli(['publish', STAGE, destination_root, RUN])
    run_cli(['check', destination_root/'runs'/RUN])
    assert (destination_root/'CURRENT').read_text().strip() == RUN
    note('Scale result published and verified. Removing marked scratch and temporary recovery script.')

def main():
    if '--inside' in sys.argv:
        inside()
        return
    if '--plan' in sys.argv:
        preflight()
        print('Verified plan: preserve 120 builds/240 reads; rerun 1 incomplete repeat and 49 remaining entries. No files changed.')
        return
    with (SCRATCH/'.recovery.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        code = 1
        try:
            if (STAGE / 'recovery.json').exists():
                recovery = json.loads((STAGE / 'recovery.json').read_text())
                assert recovery['source_commit'] == SHA
                assert len(rows(STAGE / '10_export.csv')) == 120
                assert len(rows(STAGE / '20_access.csv')) == 240
                check_access(rows(STAGE / '20_access.csv'))
                note('Resuming dependency setup; no new measurements were run yet.')
            else:
                prepare()
            command = '/usr/bin/python3 ' + str(Path(__file__).resolve()) + ' --inside'
            subprocess.run(['/nix/var/nix/profiles/default/bin/nix-shell', str(CODE/'default.nix'), '-A','shell','--run', command], check=True)
            safe_remove(SCRATCH)
            Path(__file__).unlink()
            code = 0
            note('SUCCESS: scale completed; scratch and temporary script removed. Source download cache retained.')
        except BaseException:
            traceback.print_exc()
            note('FAILED: retained marked scratch and original evidence for diagnosis; no partial result published.')
        finally:
            atomic(STATE/'benchmark.exit', (str(code)+'\n').encode())
            pid_file = STATE/'benchmark.pid'
            if pid_file.exists() and pid_file.read_text().strip() == str(os.getpid()):
                pid_file.unlink()
        sys.exit(code)

if __name__ == '__main__':
    main()
